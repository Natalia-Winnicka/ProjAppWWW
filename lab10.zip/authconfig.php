<?php

 $myusername = "user123";
 $mypassword = "password123";

?>