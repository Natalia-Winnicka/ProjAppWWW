<div>
    <form method="post" action="">
        <label for="nazwa">nazwa:</label>
        <input type="text" name="nazwa" required>
        <br>
        <label for="id">id:</label>
        <textarea name="id" required></textarea>
        <br>
        <label for="matka">Matka:</label>
        <input type="checkbox" name="status">
        <br>
        <button type="submit">Dodaj pods</button>
    </form>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = dbConnect();
    $stmt = $conn->prepare("INSERT INTO page_list (page_title, page_content, matka) VALUES (?, ?, ?)");

    if ($stmt === false) {
        die("Error in query: " . $conn->error);
    }

    $stmt->bind_param("sss", $nazwa, $id, $matka);
    $nazwa = htmlspecialchars($_POST['nazwa']);
    $id = htmlspecialchars($_POST['id']);
    $matka = htmlspecialchars($_POST['matka']);

    $stmt->execute();

    $stmt->close();
    mysqli_close($conn);

    header("Location: index.php?idp=lab7&idp1=pokaz");
    exit;
}
?>