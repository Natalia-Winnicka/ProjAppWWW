<?php
$nr_indeksu = '164441';
        $nrGrupy = '4';
        echo 'Zastosowanie metody require_once() <br />';
        echo 'Natalia Winnicka '.$nr_indeksu.' grupa '.$nrGrupy.' <br /><br />';
        
?>