<?
function FormluarzLogowania()
{
    $wynik='
    <div class="logowanie">
    <h1 class="heading">Panel CMS:</h1>
    <div class="logowanie">
    <form method="post" name="LoginForm" enctype="multipart/form-data" action="".$_SERVER['REQUEST_URI'].">
    <table
    
    '
}
?>